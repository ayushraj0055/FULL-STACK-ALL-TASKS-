const express = require("express");
const db = require("./db");
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

app.post("/commit", (req, res) => {
    db.save(req.body);
    res.json({ msg: "Committed" });
});

app.get("/history", (req, res) => {
    res.json(db.getAll());
});

app.listen(3000, () => {
    console.log("http://localhost:3000");
});
