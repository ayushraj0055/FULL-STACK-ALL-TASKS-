let commits = [];
let version = 1;

function save(data) {
    commits.push({
        version: version++,
        message: data.message,
        content: data.content,
        time: new Date()
    });
}

function getAll() {
    return commits;
}

module.exports = { save, getAll };
