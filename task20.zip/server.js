const express = require("express");
const db = require("./db");
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

app.post("/branch", (req, res) => {
    db.createBranch(req.body.name);
    res.json({ msg: "Branch created" });
});

app.post("/commit", (req, res) => {
    db.commit(req.body.message);
    res.json({ msg: "Committed" });
});

app.post("/merge", (req, res) => {
    const result = db.merge();
    res.json({ msg: result });
});

app.post("/rebase", (req, res) => {
    db.rebase();
    res.json({ msg: "Rebased" });
});

app.get("/data", (req, res) => {
    res.json(db.getData());
});

app.listen(3000, () => console.log("http://localhost:3000"));
