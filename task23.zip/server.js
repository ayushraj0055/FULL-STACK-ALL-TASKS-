const express = require("express");
const db = require("./db");
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html");
});

app.post("/generate", (req, res) => {
    const result = db.processPrompt(req.body.prompt);
    res.json(result);
});

app.listen(3000, () => {
    console.log("Server running at:");
    console.log("http://localhost:3000");
});